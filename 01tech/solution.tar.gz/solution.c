#include <stdio.h>

int main() {
  if (STRINGS[0] != '\0') {
    printf("%s\n", STRINGS);
  }
  printf("%d\n", SUM);
  return 0;
}
